# @reponse/sdk

The official TypeScript SDK for Reponse Headless Commerce. 
Use this to vibe-code your own storefront while leveraging Reponse's AI-native backend for catalog, cart, and conversational AI.

## Installation

```bash
npm install @reponse/sdk
```

## Usage

```typescript
import { Reponse } from '@reponse/sdk';

const reponse = new Reponse({
  apiKey: process.env.REPONSE_API_KEY, // e.g. sk_live_...
});

// 1. Fetch products
const response = await reponse.catalog.listProducts({ limit: 10 });
const products = response.data;

// 2. Create a Cart
const cart = await reponse.cart.create({
  currency: 'EUR',
  items: [
    { product_id: products[0].id, quantity: 1 }
  ]
});

console.log('Cart created:', cart.id);
```

## Supported Services

- `reponse.catalog` - Products and collections.
- `reponse.cart` - Shopping carts and checkout sessions.
- `reponse.orders` *(coming soon)*
- `reponse.ai` *(coming soon)*
