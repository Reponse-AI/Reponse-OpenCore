export class Reponse {
  private apiKey: string;
  private baseUrl: string;

  public catalog: Catalog;
  public cart: Cart;
  public orders: Orders;
  public tickets: Tickets;

  constructor(options: { apiKey: string; baseUrl?: string }) {
    this.apiKey = options.apiKey;
    // For local dev, allow passing http://localhost:3000/api
    this.baseUrl = options.baseUrl || 'https://api.reponse.ai/api';

    this.catalog = new Catalog(this);
    this.cart = new Cart(this);
    this.orders = new Orders(this);
    this.tickets = new Tickets(this);
  }

  async fetch(endpoint: string, options: RequestInit = {}) {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        ...options.headers,
        Authorization: `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Reponse API Error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }
}

class Catalog {
  constructor(private client: Reponse) {}

  async listProducts(options?: { limit?: number; cursor?: string; query?: string }) {
    const searchParams = new URLSearchParams();
    if (options?.limit) searchParams.set('limit', options.limit.toString());
    if (options?.cursor) searchParams.set('cursor', options.cursor);
    if (options?.query) searchParams.set('query', options.query);

    return this.client.fetch(`/v1/products?${searchParams.toString()}`);
  }

  async getProduct(id: string) {
    return this.client.fetch(`/v1/products/${id}`);
  }

  async listCollections(options?: { limit?: number }) {
    const searchParams = new URLSearchParams();
    if (options?.limit) searchParams.set('limit', options.limit.toString());
    return this.client.fetch(`/v1/collections?${searchParams.toString()}`);
  }
}

class Cart {
  constructor(private client: Reponse) {}

  async create(data: { currency?: string; items?: { product_id: string; quantity: number }[] }) {
    return this.client.fetch('/v1/carts', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async get(id: string) {
    return this.client.fetch(`/v1/carts/${id}`);
  }

  async addItems(id: string, items: { product_id: string; quantity: number }[]) {
    return this.client.fetch(`/v1/carts/${id}/items`, {
      method: 'POST',
      body: JSON.stringify({ items }),
    });
  }

  async updateItem(cartId: string, lineId: string, quantity: number) {
    return this.client.fetch(`/v1/carts/${cartId}/items/${lineId}`, {
      method: 'PUT',
      body: JSON.stringify({ quantity }),
    });
  }

  async removeItem(cartId: string, lineId: string) {
    return this.client.fetch(`/v1/carts/${cartId}/items/${lineId}`, {
      method: 'DELETE',
    });
  }
}

class Orders {
  constructor(private client: Reponse) {}

  async create(data: { cart_id: string; customer_email?: string }) {
    return this.client.fetch('/v1/orders', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async checkout(data: { cart_id: string; success_url?: string; cancel_url?: string }) {
    return this.client.fetch('/v1/checkout/stripe', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateShippingAddress(orderId: string, payload: { shipping_address: any, conversation_id?: string }) {
    return this.client.fetch(`/v1/orders/${orderId}/shipping-address`, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
  }

  async resendOrderConfirmation(orderId: string, payload: { conversation_id?: string } = {}) {
    return this.client.fetch(`/v1/orders/${orderId}/resend-confirmation`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }

  async resendInvoice(orderId: string, payload: { conversation_id?: string } = {}) {
    return this.client.fetch(`/v1/orders/${orderId}/resend-invoice`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }

  async cancel(orderId: string, payload: { reason: string, custom_reason?: string, conversation_id?: string }) {
    return this.client.fetch(`/v1/orders/${orderId}/cancel`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }
}

class Tickets {
  constructor(private client: Reponse) {}

  async list(options: { customer_email: string; status?: string }) {
    const searchParams = new URLSearchParams();
    searchParams.set('customer_email', options.customer_email);
    if (options.status) searchParams.set('status', options.status);

    return this.client.fetch(`/v1/tickets?${searchParams.toString()}`);
  }

  async get(id: string) {
    return this.client.fetch(`/v1/tickets/${id}`);
  }

  async create(data: { customer_email: string; subject: string; message: string; category?: string; order_id?: string }) {
    return this.client.fetch('/v1/tickets', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async reply(id: string, data: { message: string }) {
    return this.client.fetch(`/v1/tickets/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }
}
